---
name: Question
about: Do you have a question about  Linien?
title: ''
labels: ''
assignees: ''

---

If you have a question about Linien, consider asking it on our [discussion](https://github.com/linien-org/linien/discussions/categories/q-a) pages instead of opening an issue.
