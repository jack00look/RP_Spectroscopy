import paramiko

hostname = '192.168.1.159'
username = 'root'
password = 'root'

local_path = './Imported_files'